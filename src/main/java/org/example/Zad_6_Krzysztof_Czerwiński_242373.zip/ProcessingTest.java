package org.example;

import processing.core.*;

import java.util.ArrayList;


public class ProcessingTest extends PApplet {


    Tank tank;

    float lastTime = 0;
    float delta = 0;
    float cd = 0;
    public ArrayList<Bullet> bullets;
    public ArrayList<Enemy> enemies;
    
    public void settings() {
        size(600, 600);
    }

    public void setup() {
        background(255);

        mySetUp();
      
    }
    
    public void mySetUp(){
        tank = new Tank(height/2,width/2,loadShape("C:\\Users\\redkc\\IdeaProjects\\Processing4.2\\src\\main\\java\\org\\example\\SVG\\Tank.svg"),this);
        bullets = new ArrayList<Bullet>();
        enemies = new ArrayList<Enemy>();
    }

    public void mouseReleased(){
        tank.shape.getChild("Laser").setVisible(false);
    } 
    
    public void mousePressed() {
        bullets.add(new Bullet(tank.x,tank.y,tank.rotation,loadShape("C:\\Users\\redkc\\IdeaProjects\\Processing4.2\\src\\main\\java\\org\\example\\SVG\\Bullet.svg"),this));
        tank.shape.getChild("Laser").setVisible(true);
    }
    
    

    // Draw the shapes and handle input in draw():
    public void draw() {
        delta = millis()/1000f - lastTime;
        lastTime =  millis()/1000f;
        background(200);

        // Draw tank rotated toward mouse
        
       tank.display();

        ArrayList<Enemy> enemiesIndexes = new ArrayList<Enemy>();
        ArrayList<Bullet> bulletsIndexes = new ArrayList<Bullet>();

        for (int j = 0; j < enemies.size(); j++) {
            enemies.get(j).display(tank, delta);
            if (Math.abs(enemies.get(j).x - tank.x) < 5 && Math.abs(enemies.get(j).y - tank.y) < 5) {
                mySetUp();
            }
        }
        
        for (int i = 0; i < bullets.size(); i++) {
            bullets.get(i).display(delta);
            for (int j = 0; j < enemies.size(); j++) {
                if(Math.abs(bullets.get(i).x - enemies.get(j).x) < 50 &&  Math.abs(bullets.get(i).y - enemies.get(j).y) < 50) {
                    bullets.get(i).shape.getChild("Explosion").setVisible(true);
                    bulletsIndexes.add(bullets.get(i));
                    enemiesIndexes.add(enemies.get(j));
                }
            }
            if(bullets.get(i).time > 100) {
                bulletsIndexes.add(bullets.get(i));
            }
        }

        for (Bullet bullet : bulletsIndexes) {
            bullets.remove(bullet);
        }

        for (Enemy enemy : enemiesIndexes) {
            enemies.remove(enemy);
        }
        
        cd += delta;
        if(cd > 2){
            cd = 0;
            enemies.add(new Enemy(0,this.random(0,height),loadShape("C:\\Users\\redkc\\IdeaProjects\\Processing4.2\\src\\main\\java\\org\\example\\SVG\\Enemy.svg"),this));
        }
        
        // Draw bullet and enemy without rotation
       // shape(bullet, mouseX - 35, mouseY - 35);
       // shape(enemy, mouseX + 35, mouseY + 35);

        // Check for WASD input
       
    }
    public static void main(String... args) {
        PApplet.main(new String[]{"org.example.ProcessingTest"});
    }
}